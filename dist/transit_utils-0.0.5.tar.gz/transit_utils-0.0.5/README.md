transit_utils
===============================

version number: 0.0.1
author: Brian Jackson

Overview
--------

A small collection of methods for analyzing transit data

Installation / Usage
--------------------

To install use pip:

    $ pip install transit_utils


Or clone the repo:

    $ git clone https://github.com/decaelus/transit_utils.git
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD